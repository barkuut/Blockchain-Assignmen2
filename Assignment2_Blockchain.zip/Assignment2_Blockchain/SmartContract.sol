// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title MessageBoard - MG3012 Assignment 2 mini dApp
/// @notice Stores a public message on-chain; anyone can update it, only the owner can reset it.
contract MessageBoard {
    address public owner;
    string private message;
    address private lastUpdater;
    uint256 private updateCount;

    event MessageUpdated(address indexed by, string newMessage, uint256 count);
    event MessageReset(address indexed by);

    constructor(string memory _initialMessage) {
        owner = msg.sender;
        message = _initialMessage;
        lastUpdater = msg.sender;
    }

    // ---------- WRITE functions ----------

    /// @notice Update the stored message (costs gas)
    function setMessage(string calldata _newMessage) external {
        require(bytes(_newMessage).length > 0, "Message cannot be empty");
        require(bytes(_newMessage).length <= 140, "Max 140 characters");
        message = _newMessage;
        lastUpdater = msg.sender;
        updateCount += 1;
        emit MessageUpdated(msg.sender, _newMessage, updateCount);
    }

    /// @notice Owner-only: clear the message back to a default
    function resetMessage() external {
        require(msg.sender == owner, "Only owner can reset");
        message = "Message reset by owner";
        lastUpdater = msg.sender;
        updateCount += 1;
        emit MessageReset(msg.sender);
    }

    // ---------- READ functions (free) ----------

    function getMessage() external view returns (string memory) {
        return message;
    }

    function getLastUpdater() external view returns (address) {
        return lastUpdater;
    }

    function getUpdateCount() external view returns (uint256) {
        return updateCount;
    }
}
