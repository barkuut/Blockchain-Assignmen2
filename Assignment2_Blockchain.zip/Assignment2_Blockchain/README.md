# MG3012 – Assignment 2: MessageBoard dApp

**Student:** Muhammad Bin Barkaat  
**Course:** MG3012 Blockchain Technology for Business (BSFT, Fall 2026)  
**Instructor:** Dr. Usama Arshad  
**Network:** Ethereum Sepolia testnet

## Contract address
`0x69fC3e706E0eA176EF3dB681DC56eF6d02aEB9E1`
https://sepolia.etherscan.io/tx/0x88681522ed7a28898ed529ecd89c901b7e03a1224bfdd971b36d3a5e45599646

## What it does
`MessageBoard` stores a public message on-chain. Anyone can update it; only the owner can reset it.

| Function | Type | Description |
|---|---|---|
| `setMessage(string)` | write | Updates the message (1–140 chars), emits `MessageUpdated` |
| `resetMessage()` | write | Owner-only reset |
| `getMessage()` | read | Returns current message |
| `getLastUpdater()` | read | Address of last updater |
| `getUpdateCount()` | read | Number of updates so far |

## Files
- `SmartContract.sol` – Solidity contract
- `index.html` – frontend (HTML + JS with ethers.js v6)
- `style.css` – styling
- `screenshots/` – deployment, connection and transaction screenshots

## Setup
1. Open [Remix IDE](https://remix.ethereum.org), create `SmartContract.sol` and paste the code.
2. Compile with Solidity 0.8.20+ (Solidity Compiler tab).
3. In *Deploy & Run*, choose **Injected Provider – MetaMask**, make sure MetaMask is on **Sepolia** (fund it from a Sepolia faucet).
4. Enter an initial message (e.g. `Hello Sepolia`) next to **Deploy**, confirm in MetaMask.
5. Copy the deployed contract address and paste it into `CONTRACT_ADDRESS` in `index.html`.
6. Open `index.html` (use VS Code *Live Server* or `python -m http.server` and visit `http://localhost:8000`).
7. Click **Connect MetaMask → Read Contract Data → Update Message**.

## Screenshots
1. `screenshots/1_deployment.png` – contract deployed in Remix
2. `screenshots/2_connected.png` – UI connected to MetaMask
3. `screenshots/3_transaction.png` – successful write transaction
